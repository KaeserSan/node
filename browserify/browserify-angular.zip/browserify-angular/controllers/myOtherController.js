function myOtherController($scope) {
	$scope.text = "Welcome to SkylabCoders!";
}

module.exports = myOtherController;